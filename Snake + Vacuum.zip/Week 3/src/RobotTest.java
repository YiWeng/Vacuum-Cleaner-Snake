
public class RobotTest {
	
	static int[][] Map = new int[8][8];
	
	public static void main(String[] args){
		Map[0][0] = 1;
		
		
		RandomMove Move = new RandomMove();
		Thread t1 = new Thread(Move);
		
		Display Disp = new Display();
		Thread t2 = new Thread(Disp);
		
		t1.start();
		t2.start();
	}
}
