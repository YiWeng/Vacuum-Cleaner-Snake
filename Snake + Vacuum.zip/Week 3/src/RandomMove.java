import java.util.Random;

public class RandomMove implements Runnable {

	Random rand = new Random();
	int randomNum;
	int countX = 0;
	int countY = 0;
	int end = 0;

	public synchronized void run(){
		
		while (end != 1){
			
			randomNum = rand.nextInt(8)+1;
			
			for(int counterY = 0; counterY <= 7; counterY++){
				for (int counterX = 0; counterX <=7; counterX++){
					if (RobotTest.Map[counterX][counterY] == 1){
						countX = counterX;
						countY = counterY;
					}
				}
			}
			
			if (randomNum == 1){
				if (countY < 7){
					RobotTest.Map[countX][countY] = 0;
					RobotTest.Map[countX][countY+1] = 1;
				}
			}
			else if (randomNum == 2){
				if (countX < 7){
					RobotTest.Map[countX][countY] = 0;
					RobotTest.Map[countX+1][countY] = 1;
				}
			}
			else if (randomNum == 3){
				if (countY > 0){
					RobotTest.Map[countX][countY] = 0;
					RobotTest.Map[countX][countY-1] = 1;
				}
			}
			else if (randomNum == 4){
				if (countX > 0){
					RobotTest.Map[countX][countY] = 0;
					RobotTest.Map[countX-1][countY] = 1;
				}
			}
			else if (randomNum == 5){
				if (countX < 7 && countY < 7){
					RobotTest.Map[countX][countY] = 0;
					RobotTest.Map[countX+1][countY+1] = 1;
				}
			}
			else if (randomNum == 6){
				if (countY > 0 && countX < 7){
					RobotTest.Map[countX][countY] = 0;
					RobotTest.Map[countX+1][countY-1] = 1;
				}
			}
			else if (randomNum == 7){
				if (countY > 0 && countX > 0){
					RobotTest.Map[countX][countY] = 0;
					RobotTest.Map[countX-1][countY-1] = 1;
				}
			}
			else{
				if (countX > 0 && countY < 7){
					RobotTest.Map[countX][countY] = 0;
					RobotTest.Map[countX-1][countY+1] = 1;
				}
			}
			
			try{
				Thread.sleep(600);
			}
			catch(InterruptedException e) {
				
			}
		}
	}
	
}
