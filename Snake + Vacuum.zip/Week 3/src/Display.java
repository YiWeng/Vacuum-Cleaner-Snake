
public class Display implements Runnable{

	int end = 0;
	
	public  void run(){
		while (end != 1){
			
			
			
			System.out.print("\n------------------------------------------");
			
			synchronized(RobotTest.Map){
				for(int counterY = 0; counterY <= 7; counterY++){
					System.out.println();
					for (int counterX = 0; counterX <=7; counterX++){
						System.out.print(RobotTest.Map[counterX][counterY]);
					}
				}
			}
			
			try{
				Thread.sleep(300);
			}
			catch(InterruptedException e) {
				
			}
			
		}
	}
}
