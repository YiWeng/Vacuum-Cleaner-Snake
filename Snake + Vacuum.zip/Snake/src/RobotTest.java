
public class RobotTest {
	
	
	public static void main(String[] args){
		
		int[][] Map = new int[8][8];
		Map[0][0] = 1;
		
		
		RandomMove Move = new RandomMove(Map);
		Thread t1 = new Thread(Move);
		
		Display Disp = new Display(Map);
		Thread t2 = new Thread(Disp);
		
		t1.start();
		t2.start();
	}
}
