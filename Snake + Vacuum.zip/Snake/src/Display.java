
public class Display implements Runnable{

	int end = 0;
	int[][] Map;
	
	public Display(int[][] map){
		Map = map;
	}
	
	public  void run(){
		while (end != 1){
			
			
			
			System.out.print("\n------------------------------------------");
			
			synchronized(Map){
				for(int counterY = 0; counterY <= 7; counterY++){
					System.out.println();
					for (int counterX = 0; counterX <=7; counterX++){
						System.out.print(Map[counterX][counterY]);
					}
				}
			}
			
			try{
				Thread.sleep(300);
			}
			catch(InterruptedException e) {
				
			}
			
		}
	}
}
