import java.util.Random;

public class RandomMove implements Runnable {

	Random rand = new Random();
	int randomNum;
	int countX = 0;
	int countY = 0;
	int end = 0;
	int[][] Map;

	public RandomMove(int[][] map){
		Map = map;
	}
	
	public synchronized void run(){
		
		while (end != 1){
			
			randomNum = rand.nextInt(4)+1;
			
			for(int counterY = 0; counterY <= 7; counterY++){
				for (int counterX = 0; counterX <=7; counterX++){
					if (Map[counterX][counterY] == 1){
						countX = counterX;
						countY = counterY;
					}
				}
			}
			
			if (randomNum == 1){
				if (countY < 7 && Map[countX][countY+1] == 0){
					for(int counterY = 0; counterY <= 7; counterY++){
						for (int counterX = 0; counterX <=7; counterX++){
							if (Map[counterX][counterY] == 3){
								Map[counterX][counterY] = 0;
							}
							if (Map[counterX][counterY] == 2){
								Map[counterX][counterY] = 3;
							}
						}
					Map[countX][countY] = 2;
					Map[countX][countY+1] = 1;
					}
				}
			}
			else if (randomNum == 2){
				if (countX < 7 && Map[countX+1][countY] == 0){
					for(int counterY = 0; counterY <= 7; counterY++){
						for (int counterX = 0; counterX <=7; counterX++){
							if (Map[counterX][counterY] == 3){
								Map[counterX][counterY] = 0;
							}
							if (Map[counterX][counterY] == 2){
								Map[counterX][counterY] = 3;
							}
						}
					}
					Map[countX][countY] = 2;
					Map[countX+1][countY] = 1;
				}
			}
			else if (randomNum == 3){
				if (countY > 0 && Map[countX][countY-1] == 0){
					for(int counterY = 0; counterY <= 7; counterY++){
						for (int counterX = 0; counterX <=7; counterX++){
							if (Map[counterX][counterY] == 3){
								Map[counterX][counterY] = 0;
							}
							if (Map[counterX][counterY] == 2){
								Map[counterX][counterY] = 3;
							}
						}
					}
					Map[countX][countY] = 2;
					Map[countX][countY-1] = 1;
				}
			}
			else{
				if (countX > 0 && Map[countX-1][countY] == 0){
					for(int counterY = 0; counterY <= 7; counterY++){
						for (int counterX = 0; counterX <=7; counterX++){
							if (Map[counterX][counterY] == 3){
								Map[counterX][counterY] = 0;
							}
							if (Map[counterX][counterY] == 2){
								Map[counterX][counterY] = 3;
							}
						}
					}
					Map[countX][countY] = 2;
					Map[countX-1][countY] = 1;
				}
			}
			
			try{
				Thread.sleep(600);
			}
			catch(InterruptedException e) {
				
			}
		}
	}
	
}
